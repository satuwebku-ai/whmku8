<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CmsCategory extends Model
{
    use UsesCmsContentTable;

    public const CONTENT_TYPE = 'category';

    public const SLUG_FALLBACK = 'kategori';

    protected $fillable = ['name', 'slug'];

    public function posts(): HasMany
    {
        return $this->hasMany(CmsPost::class, 'cms_category_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class HostingAccount extends Model
{
    use HasFactory;

    protected $fillable = [
        'client_id', 'product_id', 'server_id', 'domain', 'package', 'server', 'panel',
        'username', 'price', 'billing_cycle', 'billing_mode', 'hourly_rate', 'last_billed_at', 'panel_suspend_error', 'status', 'next_due_date',
        'provision_status', 'provision_message', 'provisioning_started_at', 'provisioning_finished_at', 'provisioning_attempts', 'provisioning_key', 'client_details', 'internal_notes',
        'cancellation_status', 'cancellation_reason', 'cancellation_requested_at',
        'cancellation_admin_note', 'renewal_invoice_id',
        'pending_upgrade_product_id', 'pending_upgrade_invoice_id', 'pending_upgrade_price',
        'credentials_sent_at', 'credentials_email_failed_at',
    ];

    protected function casts(): array
    {
        return [
            'price' => 'decimal:2',
            'pending_upgrade_price' => 'decimal:2',
            'hourly_rate' => 'decimal:4',
            'last_billed_at' => 'datetime',
            'provisioning_started_at' => 'datetime',
            'provisioning_finished_at' => 'datetime',
            'provisioning_attempts' => 'integer',
            'next_due_date' => 'date',
            'cancellation_requested_at' => 'datetime',
            'client_details' => 'encrypted',
            'credentials_sent_at' => 'datetime',
            'credentials_email_failed_at' => 'datetime',
        ];
    }

    public function hasPendingCancellation(): bool
    {
        return $this->cancellation_status === 'requested';
    }

    public function renewalInvoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class, 'renewal_invoice_id');
    }

    /**
     * Lepaskan invoice perpanjangan yang masih menunggu dari layanan.
     *
     * Invoice renewal tidak memakai order_id; relasinya disimpan di
     * hosting_accounts.renewal_invoice_id. Karena itu relasi ini harus
     * dibersihkan saat layanan dihentikan, kalau tidak invoice lama akan
     * tetap tampil dan masih terlihat seperti tagihan yang dapat dibayar.
     */
    public function clearPendingRenewalInvoice(): void
    {
        if (! $this->renewal_invoice_id) {
            return;
        }

        $invoice = Invoice::find($this->renewal_invoice_id);

        // Invoice yang sudah lunas tidak boleh dibatalkan. Relasinya tetap
        // dibersihkan agar invoice itu tidak diproses ulang sebagai renewal.
        if ($invoice && in_array($invoice->status, ['unpaid', 'overdue'], true)) {
            $note = trim((string) $invoice->notes);
            $cancellationNote = 'Dibatalkan otomatis karena layanan di-terminate.';

            $invoice->update([
                'status' => 'cancelled',
                'notes' => $note
                    ? $note . "\n" . $cancellationNote
                    : $cancellationNote,
            ]);
        }

        $this->update(['renewal_invoice_id' => null]);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(\App\Models\Product::class);
    }

    public function pendingUpgradeProduct(): BelongsTo
    {
        return $this->belongsTo(\App\Models\Product::class, 'pending_upgrade_product_id');
    }

    public function pendingUpgradeInvoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class, 'pending_upgrade_invoice_id');
    }

    /**
     * Paket lain yang boleh jadi tujuan upgrade mandiri klien. Dibatasi
     * dengan sengaja supaya tidak ada kombinasi yang berujung error atau
     * butuh campur tangan admin:
     *   - kategori produk sama (upgrade hosting ke hosting, bukan ke domain)
     *   - server akun saat ini harus menjadi tujuan produk langsung atau
     *     anggota aktif dari grup tujuan (upgrade tidak memindahkan akun)
     *   - harga siklus yang sama lebih tinggi (downgrade tidak ditangani
     *     di sini karena butuh skema refund/kredit yang belum dibangun)
     */
    public function upgradeEligibleProducts()
    {
        if (! $this->product_id || ! $this->product) {
            return \App\Models\Product::whereRaw('1 = 0')->get(); // kosong — akun lama tanpa jejak produk
        }

        if (! $this->server_id) {
            return \App\Models\Product::whereRaw('1 = 0')->get();
        }

        return \App\Models\Product::where('product_category_id', $this->product->product_category_id)
            ->where(function ($query) {
                $query->where('server_id', $this->server_id)
                    ->orWhere(function ($groupProducts) {
                        $groupProducts->whereNull('server_id')
                            ->whereHas('serverGroup', function ($group) {
                                $group->where('is_active', true)
                                    ->whereHas('servers', function ($server) {
                                        $server->whereKey($this->server_id)
                                            ->where('servers.panel', 'cpanel')
                                            ->whereNull('servers.vps_provider')
                                            ->where('servers.is_active', true)
                                            ->where('servers.is_maintenance', false)
                                            ->where('server_group_server.is_active', true);
                                    });
                            });
                    });
            })
            ->where('is_active', true)
            ->where('id', '!=', $this->product_id)
            ->get()
            ->filter(function ($p) {
                $newPrice = $this->priceForProductCycle($p);

                return $newPrice !== null && $newPrice > (float) $this->price;
            })
            ->values();
    }

    /**
     * Harga siklus produk untuk kelompok harga client layanan ini.
     */
    public function priceForProductCycle(\App\Models\Product $product): ?float
    {
        $pricing = $product->pricingForClientCycle(
            $this->client?->client_group_id,
            $this->billing_cycle,
        );

        return $pricing === null ? null : (float) $pricing['price'];
    }

    /**
     * Selisih biaya prorata untuk upgrade ke produk tertentu — hanya
     * menghitung sisa hari sampai next_due_date, BUKAN menagih ulang
     * dari awal siklus. Mulai siklus berikutnya, tagihan otomatis
     * memakai harga baru (lihat renewalAmount()).
     */
    public function prorateUpgrade(\App\Models\Product $newProduct, ?float $newPrice = null): float
    {
        $cycleDays = $this->billingCycleDays();

        $remainingDays = $this->next_due_date
            ? max(0, min($cycleDays, (int) now()->startOfDay()->diffInDays($this->next_due_date, false)))
            : $cycleDays;

        $newPrice ??= $this->priceForProductCycle($newProduct);
        if ($newPrice === null) {
            return 0.0;
        }

        $oldDailyRate = (float) $this->price / $cycleDays;
        $newDailyRate = $newPrice / $cycleDays;

        return round(($newDailyRate - $oldDailyRate) * $remainingDays);
    }

    /**
     * Selisih biaya prorata untuk memasang addon baru di tengah siklus
     * berjalan — beda dari upgrade (yang cuma bayar SELISIH harga),
     * addon itu tambahan baru sepenuhnya jadi yang diprorata adalah
     * HARGA PENUH addon-nya untuk sisa hari sampai next_due_date.
     */
    public function prorateAddon(\App\Models\Addon $addon): float
    {
        $cycleDays = $this->billingCycleDays();

        $remainingDays = $this->next_due_date
            ? max(0, min($cycleDays, (int) now()->startOfDay()->diffInDays($this->next_due_date, false)))
            : $cycleDays;

        $addonPrice = (float) $addon->priceForCycle($this->billing_cycle);

        return round(($addonPrice / $cycleDays) * $remainingDays);
    }

    private function billingCycleDays(): int
    {
        return match ($this->billing_cycle) {
            'quarterly' => 90,
            'semi_annually' => 180,
            'annually' => 365,
            'custom' => max(1, (int) ($this->product?->custom_cycle_days ?: 30)),
            default => 30,
        };
    }

    /**
     * Nominal satu siklus perpanjangan, sesuai billing_cycle layanan ini.
     */
    public function renewalAmount(): float
    {
        return (float) $this->price + $this->activeAddons()->sum('price') + $this->options()->sum('price');
    }

    public function addons(): HasMany
    {
        return $this->hasMany(HostingAccountAddon::class);
    }

    public function activeAddons(): HasMany
    {
        return $this->hasMany(HostingAccountAddon::class)->where('status', 'active');
    }

    public function options(): HasMany
    {
        return $this->hasMany(HostingAccountOption::class);
    }

    /**
     * Tanggal jatuh tempo berikutnya setelah siklus ini lunas.
     */
    public function nextCycleDate(?\Carbon\CarbonInterface $paidAt = null): \Carbon\Carbon
    {
        $base = $this->next_due_date ?: $paidAt ?: now();
        $nextDueDate = $this->addBillingCycle($base);

        // Late payment must not leave the next renewal date in the past.
        // Keep the original cycle anchor while it still produces a future
        // date; otherwise begin the next cycle on the actual payment date.
        if ($paidAt && $nextDueDate->copy()->startOfDay()->lte($paidAt->copy()->startOfDay())) {
            return $this->addBillingCycle($paidAt);
        }

        return $nextDueDate;
    }

    private function addBillingCycle(\Carbon\CarbonInterface $base): \Carbon\Carbon
    {
        $base = \Carbon\Carbon::parse($base);

        if ($this->billing_cycle === 'custom') {
            return $base->addDays($this->billingCycleDays());
        }

        return match ($this->billing_cycle) {
            'quarterly' => $base->copy()->addMonths(3),
            'semi_annually' => $base->copy()->addMonths(6),
            'annually' => $base->copy()->addYear(),
            default => $base->copy()->addMonth(),
        };
    }

    public function cycleLabel(): string
    {
        return match ($this->billing_cycle) {
            'quarterly' => '3 bulan',
            'semi_annually' => '6 bulan',
            'annually' => '1 tahun',
            default => 'bulanan',
        };
    }

    /**
     * Buat invoice perpanjangan untuk layanan ini. Dipakai DUA tempat:
     * perintah terjadwal (lumora:generate-renewal-invoices) untuk H-7
     * otomatis, dan tombol "Perpanjang Sekarang" klien untuk permintaan
     * manual kapan saja. Disatukan di sini supaya logikanya tidak pernah
     * berbeda antara jalur otomatis dan jalur manual.
     */
    public function createRenewalInvoice(): \App\Models\Invoice
    {
        return app(\App\Services\Billing\RenewalInvoiceService::class)->createHostingInvoice($this);
    }


    /**
     * Layanan ini punya spesifikasi VM (JSON) tersimpan di kolom
     * "package", bukan sekadar nama paket biasa (mis. nama plan WHM).
     *
     * CATATAN: kolom yang dibaca adalah `package` (milik tabel
     * hosting_accounts), BUKAN `panel_package` -- yang terakhir itu
     * kolom di tabel products. Sempat keliru dan membuat tagihan per
     * jam tidak pernah jalan karena spek selalu terbaca kosong.
     */
    public function hasVmSpec(): bool
    {
        if (! $this->package) {
            return false;
        }

        $decoded = json_decode($this->package, true);

        return is_array($decoded) && isset($decoded['vcpu']);
    }

    public function vmSpec(): array
    {
        $decoded = json_decode((string) $this->package, true) ?: [];

        return [
            'vcpu'           => (int) ($decoded['vcpu'] ?? 1),
            'ram'            => (int) ($decoded['ram'] ?? 1024),
            'disk'           => (int) ($decoded['disk'] ?? 20),
            'os_name'        => $decoded['os_name'] ?? 'linux',
            'backup_enabled' => (bool) ($decoded['backup_enabled'] ?? false),
            'snapshot_gb'    => (float) ($decoded['snapshot_gb'] ?? 0),
            // Provider berbasis size (mis. DigitalOcean): slug size dipakai
            // menghitung harga modal & tarif markup per jam.
            'provider_size'  => $decoded['provider_size'] ?? null,
        ];
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function serverModel(): BelongsTo
    {
        return $this->belongsTo(Server::class, 'server_id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    public function logs(): HasMany
    {
        return $this->hasMany(HostingAccountLog::class);
    }

    public function addonDomains(): HasMany
    {
        return $this->domains();
    }

    public function domains(): HasMany
    {
        return $this->hasMany(HostingDomain::class);
    }
}

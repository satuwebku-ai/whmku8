<?php

namespace App\Console\Commands;

use App\Models\Domain;
use App\Models\HostingAccount;
use App\Models\Setting;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Membuat invoice perpanjangan otomatis untuk hosting & domain yang masa
 * aktifnya mendekati habis — jantung dari pendapatan berulang bisnis
 * hosting. Tanpa perintah ini, layanan yang sudah lewat jatuh tempo tidak
 * pernah ditagih ulang secara otomatis; admin harus mengingat dan membuat
 * invoice perpanjangan satu per satu secara manual.
 *
 * Dijalankan harian lewat scheduler (lihat routes/console.php).
 */
class GenerateRenewalInvoices extends Command
{
    /**
     * Domain tidak boleh ditagih dua bulan lebih awal hanya karena admin
     * mengatur jendela invoice hosting sampai 60 hari. Untuk domain, batas
     * otomatis yang wajar adalah maksimal H-30.
     */
    private const MAX_DOMAIN_DAYS_BEFORE = 30;

    protected $signature = 'lumora:generate-renewal-invoices
                            {--dry : Hanya tampilkan yang akan dibuat, tanpa benar-benar membuat invoice}';

    protected $description = 'Buat invoice perpanjangan untuk hosting & domain yang mendekati jatuh tempo';

    
    public function handle(): int
    {
        return $this->handleJob();
    }

    private function handleJob(): int
    {
        $daysBefore = (int) Setting::get('renewal_invoice_days_before', 7);
        $dry = $this->option('dry');

        $this->info("Jendela pembuatan invoice: H-{$daysBefore} sebelum jatuh tempo.");
        $this->newLine();

        $failed = 0;
        $hostingCount = $this->processHosting($daysBefore, $dry, $failed);
        $domainCount = $this->processDomains(min($daysBefore, self::MAX_DOMAIN_DAYS_BEFORE), $dry, $failed);

        $this->newLine();
        $this->info($dry
            ? "Simulasi selesai — {$hostingCount} invoice hosting + {$domainCount} invoice domain AKAN dibuat."
            : "Selesai — {$hostingCount} invoice hosting + {$domainCount} invoice domain berhasil dibuat, {$failed} gagal.");

        return $failed > 0 ? self::FAILURE : self::SUCCESS;
    }

    /**
     * Proses hosting account yang aktif dan mendekati next_due_date.
     */
    private function processHosting(int $daysBefore, bool $dry, int &$failed): int
    {
        $accounts = HostingAccount::with('client')
            ->where('status', 'active')
            ->whereNotNull('next_due_date')
            ->whereNull('renewal_invoice_id') // belum ada invoice perpanjangan yang menunggu
            ->whereDate('next_due_date', '<=', now()->addDays($daysBefore)->toDateString())
            ->get();

        $count = 0;

        foreach ($accounts as $hosting) {
            if (! $hosting->client) {
                $failed++;
                $this->error("        hosting #{$hosting->id} tidak memiliki klien.");
                continue;
            }

            $this->line("  [Hosting] {$hosting->domain} — jatuh tempo {$hosting->next_due_date->format('d M Y')} → {$hosting->client->email}");

            if ($dry) {
                $count++;
                continue;
            }

            try {
                DB::transaction(fn () => $hosting->createRenewalInvoice());
                $count++;
            } catch (Throwable $e) {
                $failed++;
                $this->error('        gagal: ' . $e->getMessage());
                Log::error('Gagal membuat invoice perpanjangan hosting: ' . $e->getMessage(), ['hosting_account_id' => $hosting->id]);
            }
        }

        return $count;
    }

    /**
     * Proses domain aktif yang auto_renew-nya menyala dan masuk jendela
     * maksimal H-30. Jendela domain sengaja tidak mengikuti nilai hosting
     * sampai H-60 agar invoice tidak muncul terlalu dini.
     */
    private function processDomains(int $daysBefore, bool $dry, int &$failed): int
    {
        $domains = Domain::with('client', 'tld')
            ->where('status', 'active')
            ->where('auto_renew', true)
            ->whereNotNull('expiry_date')
            ->whereNull('renewal_invoice_id')
            ->whereDate('expiry_date', '>=', now()->toDateString())
            ->whereDate('expiry_date', '<=', now()->addDays($daysBefore)->toDateString())
            ->get();

        $count = 0;

        foreach ($domains as $domain) {
            if (! $domain->client) {
                $failed++;
                $this->error("        domain #{$domain->id} tidak memiliki klien.");
                continue;
            }

            $this->line("  [Domain]  {$domain->domain_name} — kedaluwarsa {$domain->expiry_date->format('d M Y')} → {$domain->client->email}");

            if ($dry) {
                $count++;
                continue;
            }

            try {
                DB::transaction(fn () => $domain->createRenewalInvoice());
                $count++;
            } catch (Throwable $e) {
                $failed++;
                $this->error('        gagal: ' . $e->getMessage());
                Log::error('Gagal membuat invoice perpanjangan domain: ' . $e->getMessage(), ['domain_id' => $domain->id]);
            }
        }

        return $count;
    }
}

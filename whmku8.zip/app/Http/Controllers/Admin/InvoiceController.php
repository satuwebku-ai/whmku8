<?php

namespace App\Http\Controllers\Admin;

use App\Services\Billing\DeletionGuard;
use App\Exceptions\Billing\BillingException;
use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Invoice;
use App\Models\Order;
use App\Services\Billing\InvoiceService;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;

class InvoiceController extends Controller
{

    public function unpaidBootstrap(Request $request): View
    {
        return view('admin.invoices.index', $this->invoiceListData($request, 'unpaid'));
    }

    public function paidBootstrap(Request $request): View
    {
        return view('admin.invoices.index', $this->invoiceListData($request, 'paid'));
    }

    public function overdueBootstrap(Request $request): View
    {
        return view('admin.invoices.index', $this->invoiceListData($request, 'overdue'));
    }

    public function cancelledBootstrap(Request $request): View
    {
        return view('admin.invoices.index', $this->invoiceListData($request, 'cancelled'));
    }

    /**
     * Pratinjau versi Bootstrap -- data & filter sama persis, cuma
     * tampilannya beda. Halaman asli tidak tersentuh.
     */
    public function invoicesBootstrap(Request $request): View
    {
        return view('admin.invoices.index', $this->invoiceListData($request, null));
    }

    private function invoiceListData(Request $request, ?string $status): array
    {
        $invoices = Invoice::query()
            ->with('client')
            ->when($status, fn ($q) => $q->where('status', $status))
            ->when($request->search, fn ($q) => $q->where('invoice_number', 'like', "%{$request->search}%"))
            ->latest()
            ->paginate(10)
            ->withQueryString();

        return ['invoices' => $invoices, 'activeStatus' => $status];
    }

    /**
     * Route ini sudah ada di routes/admin.php sejak lama tapi method-nya
     * belum pernah dibuat -- klik tombol download PDF di panel admin
     * selalu 404. Memakai template PDF yang SAMA dengan
     * Client\InvoiceController::downloadPdf() (client.invoices.pdf)
     * supaya invoice yang dilihat admin & klien identik persis, bukan
     * dua template yang bisa diam-diam berbeda.
     */
    public function pdf(Invoice $invoice): Response
    {
        $invoice->load(['order', 'items.order', 'client']);

        $pdf = Pdf::loadView('client.invoices.pdf', compact('invoice'))->setPaper('a4');

        return $pdf->download("Invoice-{$invoice->invoice_number}.pdf");
    }

    public function detailsBootstrap(Invoice $invoice): View
    {
        $invoice->load(['client', 'order', 'items.order']);

        return view('admin.invoices.details', compact('invoice'));
    }

    public function createBootstrap(): View
    {
        $clients = Client::orderBy('name')->get();
        $orders = Order::orderBy('order_number')->get();

        return view('admin.invoices.form', ['invoice' => new Invoice(), 'clients' => $clients, 'orders' => $orders]);
    }

    public function store(Request $request, InvoiceService $invoices): RedirectResponse
    {
        $data = $this->validated($request);

        $invoices->create($data);

        return redirect()->route('admin.invoices')->with('success', 'Invoice berhasil dibuat.');
    }

    public function editBootstrap(Invoice $invoice): View
    {
        $invoice->load('items.order');
        $clients = Client::orderBy('name')->get();
        $orders = Order::orderBy('order_number')->get();

        return view('admin.invoices.form', ['invoice' => $invoice, 'clients' => $clients, 'orders' => $orders]);
    }

    public function update(Request $request, Invoice $invoice, InvoiceService $invoices): RedirectResponse
    {
        $data = $this->validated($request);

        // Order terkait menentukan provisioning & status order saat invoice
        // dibayar, jadi tidak boleh diganti lewat form edit. Hanya invoice
        // manual baru (store) yang boleh memilihnya.
        unset($data['order_id']);

        // Invoice yang sudah lunas/refund adalah catatan akuntansi: nominal,
        // klien, dan tanggal tidak boleh diubah diam-diam dari form.
        if (in_array($invoice->status, ['paid', 'refunded'], true)) {
            $data = array_intersect_key($data, array_flip(['notes']));
            $data['status'] = $invoice->status;
        } elseif ($invoice->isSystemGenerated()) {
            // Invoice buatan sistem: nominal berasal dari item invoice.
            unset($data['client_id'], $data['amount'], $data['tax'], $data['discount'], $data['tax_id']);
        }

        if (($data['status'] ?? null) === 'paid' && ! $invoice->paid_at) {
            $data['paid_at'] = now();
        }

        $invoices->update($invoice, $data);

        return redirect()->route('admin.invoices')->with('success', 'Invoice berhasil diperbarui.');
    }

    public function destroy(Invoice $invoice, DeletionGuard $guard): RedirectResponse
    {
        $reason = $guard->deleteLocked($invoice, fn ($i) => $guard->forInvoice($i));

        if ($reason) {
            return back()->with('error', $reason);
        }

        $guard->audit('invoice', "Invoice {$invoice->invoice_number} dihapus",
            "Soft delete, bisa dipulihkan: php artisan records:restore invoice {$invoice->id}", $invoice->client_id);

        return redirect()->route('admin.invoices')->with('success', 'Invoice dihapus (soft delete, bisa dipulihkan lewat php artisan records:restore).');
    }

    /**
     * Tandai invoice lunas.
     */
    public function markPaid(Request $request, InvoiceService $invoices): RedirectResponse
    {
        try {
            $invoice = $invoices->findOrFail((int) $request->input('invoice_id'));
            $invoices->markPaid($invoice, $request->input('payment_method'));
        } catch (BillingException $e) {
            return back()->with('error', $e->getMessage());
        }

        return back()->with('success', "Invoice {$invoice->invoice_number} ditandai lunas.");
    }

    /**
     * Tandai invoice belum lunas (batalkan status lunas).
     */
    public function markUnpaid(Request $request, InvoiceService $invoices): RedirectResponse
    {
        try {
            $invoice = $invoices->findOrFail((int) $request->input('invoice_id'));
            $invoices->markUnpaid($invoice);
        } catch (BillingException $e) {
            return back()->with('error', $e->getMessage());
        }

        return back()->with('success', "Invoice {$invoice->invoice_number} ditandai belum lunas.");
    }

    /**
     * Batalkan invoice. Pelepasan renewal_invoice_id di domain/hosting
     * terkait (supaya layanan tidak macet permanen) ada di
     * InvoiceService::cancel(), bukan di sini lagi.
     */
    public function cancel(Request $request, InvoiceService $invoices): RedirectResponse
    {
        try {
            $invoice = $invoices->findOrFail((int) $request->input('invoice_id'));
            $invoices->cancel($invoice);
        } catch (BillingException $e) {
            return back()->with('error', $e->getMessage());
        }

        return back()->with('success', "Invoice {$invoice->invoice_number} dibatalkan.");
    }

    /**
     * Simpan catatan invoice (memakai kolom "notes" yang sudah ada sejak Fase 2).
     */
    public function invoiceNotes(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'invoice_id' => ['required', \Illuminate\Validation\Rule::exists('invoices', 'id')->whereNull('deleted_at')],
            'notes' => ['nullable', 'string'],
        ]);

        $invoice = Invoice::findOrFail($data['invoice_id']);
        $invoice->update(['notes' => $data['notes']]);

        return back()->with('success', 'Catatan invoice berhasil disimpan.');
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'client_id'      => ['required', 'exists:clients,id'],
            'order_id'       => ['nullable', \Illuminate\Validation\Rule::exists('orders', 'id')->whereNull('deleted_at')],
            'amount'         => ['required', 'numeric', 'min:0'],
            'tax'            => ['nullable', 'numeric', 'min:0'],
            'discount'      => ['nullable', 'numeric', 'min:0'],
            'tax_id'        => ['nullable', 'exists:taxes,id'],
            'status'         => ['required', 'in:unpaid,paid,overdue,cancelled,refunded'],
            'issue_date'     => ['required', 'date'],
            'due_date'       => ['required', 'date', 'after_or_equal:issue_date'],
            'payment_method' => ['nullable', 'string', 'max:100'],
            'notes'          => ['nullable', 'string'],
        ]);
    }
}
